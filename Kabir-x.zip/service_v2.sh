#!/system/bin/sh

MODDIR="/data/adb/modules/kabir-spoof"
FIREBASE_URL="https://chefz-9866d-default-rtdb.firebaseio.com"

check_firebase_auth() {
    REAL_SERIAL="$(cat "$MODDIR/device.id" 2>/dev/null)"
    [ -z "$REAL_SERIAL" ] && return 1
    RESPONSE="$(curl -s --max-time 5 "${FIREBASE_URL}/devices/${REAL_SERIAL}.json" 2>/dev/null)"
    [ -z "$RESPONSE" ] && return 1
    [ "$RESPONSE" = "null" ] && return 1
    STATUS="$(echo "$RESPONSE" | grep -o '"status":"[^"]*"' | cut -d'"' -f4)"
    EXPIRY="$(echo "$RESPONSE" | grep -o '"expiry":"[^"]*"' | cut -d'"' -f4)"
    [ "$STATUS" != "authorized" ] && return 1
    if [ -n "$EXPIRY" ] && [ "$EXPIRY" != "Lifetime" ]; then
        CURRENT_DATE="$(date +%s)"
        EXPIRY_DATE="$(date -d "$EXPIRY" +%s 2>/dev/null)"
        if [ -n "$EXPIRY_DATE" ] && [ "$CURRENT_DATE" -gt "$EXPIRY_DATE" ]; then
            return 1
        fi
    fi
    return 0
}

if ! check_firebase_auth; then
    exit 1
fi

CONF="$MODDIR/online.conf"
STATUS_FILE="$MODDIR/status_v2.json"
SERIAL_FILE="$MODDIR/device.serial"
LICENSE_FILE="$MODDIR/lease_v2.jwt"
MANIFEST_FILE="$MODDIR/checksums.manifest"
SIGNATURE_FILE="$MODDIR/checksums.sig"
VERIFY_SCRIPT="$MODDIR/verify.sh"
CTL="$MODDIR/bin/kabirctl"

[ -r "$CONF" ] && . "$CONF"

CHECK_INTERVAL="${CHECK_INTERVAL:-1800}"

case "$CHECK_INTERVAL" in
    ''|*[!0-9]*) CHECK_INTERVAL=1800 ;;
esac

[ "$CHECK_INTERVAL" -ge 300 ] 2>/dev/null || CHECK_INTERVAL=300

. "$MODDIR/common/get_serial.sh"

json_escape() {
    printf '%s' "$1" |
        sed 's/\\/\\\\/g; s/"/\\"/g; s/\r//g; s/\n/\\n/g'
}

write_status() {
    STATUS="$1"
    EXPIRES_AT="${2:-0}"
    MESSAGE="${3:-}"

    NOW="$(date +%s 2>/dev/null)"
    [ -n "$NOW" ] || NOW=0

    case "$EXPIRES_AT" in
        ''|*[!0-9]*) EXPIRES_AT=0 ;;
    esac

    TMP="$STATUS_FILE.tmp.$$"

    printf \
        '{"status":"%s","expiresAt":%s,"lastCheck":%s,"message":"%s"}\n' \
        "$(json_escape "$STATUS")" \
        "$EXPIRES_AT" \
        "$NOW" \
        "$(json_escape "$MESSAGE")" > "$TMP" || {
            rm -f "$TMP"
            return 1
        }

    chmod 0644 "$TMP" 2>/dev/null
    mv -f "$TMP" "$STATUS_FILE" || {
        rm -f "$TMP"
        return 1
    }

    chcon u:object_r:system_file:s0 "$STATUS_FILE" 2>/dev/null
    return 0
}

find_busybox() {
    for BB in \
        /data/adb/magisk/busybox \
        /data/adb/ksu/bin/busybox \
        /data/adb/ap/bin/busybox \
        "$(command -v busybox 2>/dev/null)"
    do
        if [ -n "$BB" ] && [ -x "$BB" ]; then
            printf '%s\n' "$BB"
            return 0
        fi
    done

    return 1
}

base64_decode() {
    if command -v base64 >/dev/null 2>&1; then
        base64 -d
        return $?
    fi

    if command -v toybox >/dev/null 2>&1; then
        toybox base64 -d
        return $?
    fi

    BB="$(find_busybox)"

    if [ -n "$BB" ]; then
        "$BB" base64 -d
        return $?
    fi

    return 127
}

get_lease_expiry() {
    [ -r "$LICENSE_FILE" ] || return 1

    TOKEN="$(tr -d '\r\n[:space:]' < "$LICENSE_FILE" 2>/dev/null)"
    [ -n "$TOKEN" ] || return 1

    PAYLOAD="$(printf '%s' "$TOKEN" | cut -d. -f2)"
    [ -n "$PAYLOAD" ] || return 1

    PAYLOAD="$(printf '%s' "$PAYLOAD" | tr '_-' '/+')"

    REMAINDER=$((${#PAYLOAD} % 4))

    case "$REMAINDER" in
        2) PAYLOAD="${PAYLOAD}==" ;;
        3) PAYLOAD="${PAYLOAD}=" ;;
        0) ;;
        *) return 1 ;;
    esac

    JSON="$(printf '%s' "$PAYLOAD" | base64_decode 2>/dev/null)" || return 1

    EXP="$(
        printf '%s' "$JSON" |
            tr -d '\r\n' |
            sed -n 's/.*"exp"[[:space:]]*:[[:space:]]*\([0-9][0-9]*\).*/\1/p'
    )"

    case "$EXP" in
        ''|*[!0-9]*) return 1 ;;
    esac

    printf '%s' "$EXP"
    return 0
}

existing_lease_is_active() {
    EXP="$(get_lease_expiry)" || return 1
    NOW="$(date +%s 2>/dev/null)"

    case "$NOW" in
        ''|*[!0-9]*) return 1 ;;
    esac

    [ "$EXP" -gt "$NOW" ] 2>/dev/null || return 1

    printf '%s' "$EXP"
    return 0
}

CONFIG_FILE="$MODDIR/config.json"
BT_APPLIED_FILE="$MODDIR/.bluetooth_appops_applied"

is_safe_package_name() {
    PKG="$1"

    [ -n "$PKG" ] || return 1
    [ "${#PKG}" -le 200 ] || return 1

    case "$PKG" in
        *.*) ;;
        *) return 1 ;;
    esac

    case "$PKG" in
        *[!a-zA-Z0-9._]*) return 1 ;;
    esac

    return 0
}

read_enabled_target_packages() {
    [ -r "$CONFIG_FILE" ] || return 0

    awk '
        function count_char(text, needle, count, i) {
            count = 0

            for (i = 1; i <= length(text); i++) {
                if (substr(text, i, 1) == needle) {
                    count++
                }
            }

            return count
        }

        /"active_injections"[[:space:]]*:/ {
            in_active = 1
            depth = 0
            pos = index($0, "{")

            if (pos > 0) {
                rest = substr($0, pos)
                depth += count_char(rest, "{")
                depth -= count_char(rest, "}")
            }

            next
        }

        in_active {
            if (depth == 1 && $0 ~ /^[[:space:]]*"[^"]+"[[:space:]]*:[[:space:]]*\{/) {
                pkg = $0
                sub(/^[[:space:]]*"/, "", pkg)
                sub(/"[[:space:]]*:.*/, "", pkg)

                if (pkg ~ /^[A-Za-z0-9_]+([.][A-Za-z0-9_]+)+$/) {
                    print pkg
                }
            }

            depth += count_char($0, "{")
            depth -= count_char($0, "}")

            if (depth <= 0) {
                exit
            }
        }
    ' "$CONFIG_FILE" 2>/dev/null
}

block_bluetooth_package() {
    PKG="$1"

    is_safe_package_name "$PKG" || return 1

    cmd appops set "$PKG" BLUETOOTH_SCAN ignore >/dev/null 2>&1
    cmd appops set "$PKG" BLUETOOTH_ADVERTISE ignore >/dev/null 2>&1

    return 0
}

reset_bluetooth_package() {
    PKG="$1"

    is_safe_package_name "$PKG" || return 1

    cmd appops set "$PKG" BLUETOOTH_SCAN default >/dev/null 2>&1
    cmd appops set "$PKG" BLUETOOTH_ADVERTISE default >/dev/null 2>&1

    return 0
}

list_contains_line() {
    NEEDLE="$1"
    FILE="$2"

    [ -r "$FILE" ] || return 1

    grep -Fxq "$NEEDLE" "$FILE" 2>/dev/null
}

apply_bluetooth_blocks_from_config() {
    CURRENT_FILE="$MODDIR/.bluetooth_current.tmp"
    NEW_APPLIED_FILE="$MODDIR/.bluetooth_applied.tmp"

    read_enabled_target_packages |
        while IFS= read -r PKG || [ -n "$PKG" ]; do
            is_safe_package_name "$PKG" || continue
            printf '%s\n' "$PKG"
        done |
        sort -u > "$CURRENT_FILE"

    chmod 0600 "$CURRENT_FILE" 2>/dev/null

    if [ -r "$BT_APPLIED_FILE" ]; then
        while IFS= read -r OLD_PKG || [ -n "$OLD_PKG" ]; do
            is_safe_package_name "$OLD_PKG" || continue

            if ! list_contains_line "$OLD_PKG" "$CURRENT_FILE"; then
                reset_bluetooth_package "$OLD_PKG"
            fi
        done < "$BT_APPLIED_FILE"
    fi

    : > "$NEW_APPLIED_FILE"

    while IFS= read -r PKG || [ -n "$PKG" ]; do
        is_safe_package_name "$PKG" || continue
        block_bluetooth_package "$PKG"
        printf '%s\n' "$PKG" >> "$NEW_APPLIED_FILE"
    done < "$CURRENT_FILE"

    sort -u "$NEW_APPLIED_FILE" 2>/dev/null > "$BT_APPLIED_FILE.tmp" || :
    mv -f "$BT_APPLIED_FILE.tmp" "$BT_APPLIED_FILE" 2>/dev/null
    chmod 0600 "$BT_APPLIED_FILE" 2>/dev/null
    chcon u:object_r:system_file:s0 "$BT_APPLIED_FILE" 2>/dev/null

    rm -f "$CURRENT_FILE" "$NEW_APPLIED_FILE"
}

save_original_serial() {
    SPOOFED_SERIAL="ZY22LF54XS"
    
    echo "  [✦] Spoofing serial: $SPOOFED_SERIAL" > /dev/kmsg 2>/dev/null
    
    TMP="$SERIAL_FILE.tmp.$$"
    printf '%s\n' "$SPOOFED_SERIAL" > "$TMP" || {
        rm -f "$TMP"
        return 1
    }

    chmod 0600 "$TMP" 2>/dev/null
    mv -f "$TMP" "$SERIAL_FILE" || {
        rm -f "$TMP"
        return 1
    }

    chcon u:object_r:system_file:s0 "$SERIAL_FILE" 2>/dev/null
    return 0
}

check_local_files() {
    [ -s "$MANIFEST_FILE" ] || return 11
    [ -s "$SIGNATURE_FILE" ] || return 12
    [ -f "$VERIFY_SCRIPT" ] || return 13
    [ -x "$CTL" ] || return 14
    return 0
}

handle_refresh_result() {
    RC="$1"

    case "$RC" in
        0)
            EXP="$(existing_lease_is_active)" || {
                write_status \
                    "not_activated" \
                    0 \
                    "Signed license was saved but could not be read."

                return 1
            }

            write_status \
                "active" \
                "$EXP" \
                "License active. Signed release verified."

            return 0
            ;;

        23|24)
            EXP="$(existing_lease_is_active)"

            if [ -n "$EXP" ]; then
                write_status \
                    "active" \
                    "$EXP" \
                    "Offline. Existing signed license is still active."

                return 0
            fi

            write_status \
                "offline" \
                0 \
                "Server connection failed."

            return 1
            ;;

        25)
            rm -f "$LICENSE_FILE" "$LICENSE_FILE.tmp"* 2>/dev/null

            write_status \
                "not_activated" \
                0 \
                "License inactive, expired, disabled, or release rejected."

            return 1
            ;;

        13|14)
            rm -f "$LICENSE_FILE" "$LICENSE_FILE.tmp"* 2>/dev/null

            write_status \
                "not_activated" \
                0 \
                "Original device serial is unavailable."

            return 1
            ;;

        11|12)
            rm -f "$LICENSE_FILE" "$LICENSE_FILE.tmp"* 2>/dev/null

            write_status \
                "not_activated" \
                0 \
                "Release integrity information is missing or invalid."

            return 1
            ;;

        15)
            rm -f "$LICENSE_FILE" "$LICENSE_FILE.tmp"* 2>/dev/null

            write_status \
                "not_activated" \
                0 \
                "Official server configuration is invalid."

            return 1
            ;;

        16)
            EXP="$(existing_lease_is_active)"

            if [ -n "$EXP" ]; then
                write_status \
                    "active" \
                    "$EXP" \
                    "CA store unavailable. Existing signed license is active."

                return 0
            fi

            write_status \
                "offline" \
                0 \
                "Android CA store is unavailable."

            return 1
            ;;

        20|21|22|26)
            write_status \
                "not_activated" \
                0 \
                "Native license helper failed."

            return 1
            ;;

        *)
            write_status \
                "not_activated" \
                0 \
                "License verification failed."

            return 1
            ;;
    esac
}

check_once() {
    apply_bluetooth_blocks_from_config

    if ! save_original_serial; then
        write_status \
            "not_activated" \
            0 \
            "Original serial unavailable."

        return 1
    fi

    check_local_files
    LOCAL_RC=$?

    if [ "$LOCAL_RC" -ne 0 ]; then
        handle_refresh_result "$LOCAL_RC"
        return $?
    fi

    sh "$VERIFY_SCRIPT" >/dev/null 2>&1
    RC=$?

    handle_refresh_result "$RC"
    return $?
}

case "$1" in
    --once)
        check_once
        exit $?
        ;;

    --daemon|"")
        while true; do
            check_once
            sleep "$CHECK_INTERVAL"
        done
        ;;

    *)
        exit 2
        ;;
esac