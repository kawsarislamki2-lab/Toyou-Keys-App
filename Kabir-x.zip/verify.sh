#!/system/bin/sh

MODDIR="${0%/*}"
CTL="$MODDIR/bin/kabirctl"

[ -x "$CTL" ] || exit 20

exec "$CTL" refresh
