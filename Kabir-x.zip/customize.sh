#!/system/bin/sh

get_real_device_serial() {
    REAL_SERIAL="$(getprop ro.serialno 2>/dev/null)"
    [ -z "$REAL_SERIAL" ] && REAL_SERIAL="$(cat /sys/class/android_usb/android0/iSerial 2>/dev/null)"
    [ -z "$REAL_SERIAL" ] && REAL_SERIAL="$(getprop ro.boot.serialno 2>/dev/null)"
    [ -z "$REAL_SERIAL" ] && REAL_SERIAL="$(getprop ro.product.device 2>/dev/null)"
    echo "$REAL_SERIAL"
}

REAL_SERIAL="$(get_real_device_serial)"
echo "$REAL_SERIAL" > "$MODPATH/device.id"
chmod 0644 "$MODPATH/device.id"

show_header() {
  ui_print "────────────────────────────────────────────────"
  ui_print "          KABIR X — ANTI DETECTION              "
  ui_print "────────────────────────────────────────────────"
  ui_print "░█░▄▀▄░█▀▄░█░█▀▄░░░█░█░░░░░"
  ui_print "░█░█▀█░█▀█░█░█▀▄░░░▄▀▄░░░░░"
  ui_print "░▀░▀░▀░▀▀░░▀░▀░▀░░░▀░▀░░░░░"
  ui_print "                             "
}

show_footer() {
  ui_print "────────────────────────────────────────────────"
}

log_status() {
  ui_print "  [✦] $1"
}

log_ok() {
  ui_print "  [✔] $1"
}

log_fail() {
  ui_print "  [✘] $1"
  show_footer
  exit 1
}

verify_install_integrity() {
  ui_print "  [✦] Bypassing integrity verification..."
  ui_print "  [✔] Integrity check SKIPPED (cracked version)"
  return 0
}

show_header
log_status "Initiating spoofing module setup sequence..."

ui_print " "
ui_print "  ╔══════════════════════════════════════════════════╗"
ui_print "  ║                                                  ║"
ui_print "  ║   DEVICE ID.                                     ║"
ui_print "  ║                                                  ║"
ui_print "  ║   $REAL_SERIAL"
ui_print "  ║                                                  ║"
ui_print "  ╚══════════════════════════════════════════════════╝"
ui_print " "
ui_print "  Send it to the admin to get authorization"
ui_print ""
ui_print " "

sleep 5

verify_install_integrity
show_footer

if ! $BOOTMODE; then
  log_fail "Recovery installation detected. Flash through Magisk, KernelSU or APatch Manager."
fi

if [ "$API" -lt 28 ]; then
  log_fail "Unsupported Android version. Android 9.0 or newer is required."
fi

ACTIVE_SOLUTIONS=0
ROOT_ENV=""

if command -v apd >/dev/null 2>&1; then
  ROOT_ENV="APatch"
  ACTIVE_SOLUTIONS=$((ACTIVE_SOLUTIONS + 1))
fi

if command -v ksud >/dev/null 2>&1; then
  ROOT_ENV="KernelSU"
  ACTIVE_SOLUTIONS=$((ACTIVE_SOLUTIONS + 1))
fi

if command -v magisk >/dev/null 2>&1; then
  ROOT_ENV="Magisk"
  ACTIVE_SOLUTIONS=$((ACTIVE_SOLUTIONS + 1))
fi

if [ "$ACTIVE_SOLUTIONS" -eq 0 ]; then
  log_fail "Supported root framework was not detected."
fi

if [ "$ACTIVE_SOLUTIONS" -gt 1 ]; then
  log_fail "Multiple root framework environments were detected."
fi

log_ok "$ROOT_ENV environment detected."

check_zygisk_layer() {
  if [ -d "/data/adb/modules/rezygisk" ] &&
     [ ! -f "/data/adb/modules/rezygisk/disable" ]; then
    return 0
  fi

  if [ -d "/data/adb/modules/zygisksu" ] &&
     [ ! -f "/data/adb/modules/zygisksu/disable" ]; then
    return 0
  fi

  if [ -d "/data/adb/modules/zygisk_next" ] &&
     [ ! -f "/data/adb/modules/zygisk_next/disable" ]; then
    return 0
  fi

  return 1
}

if ! check_zygisk_layer; then
  log_fail "Active Zygisk Next, ReZygisk or ZygiskSU framework was not detected."
fi

log_ok "Zygisk framework detected."

show_header
log_status "Targeting architecture variables..."

SYSTEM_ABI="$(getprop ro.product.cpu.abilist)"
ARCH_VERIFIED=false

if echo "$SYSTEM_ABI" |
  grep -qE "arm64-v8a|armv8-a|arm64|aarch64"; then
  ARCH_VERIFIED=true
  log_ok "ARM64 architecture identified."
fi

if ! $ARCH_VERIFIED; then
  log_fail "Incompatible architecture. ARM64 device is required."
fi

log_status "Configuring runtime execution permissions..."

for target_script in \
  customize.sh \
  service.sh \
  service_v2.sh \
  action.sh \
  post-fs-data.sh \
  verify.sh \
  common/get_serial.sh
do
  if [ -f "$MODPATH/$target_script" ]; then
    chmod 0755 "$MODPATH/$target_script" 2>/dev/null
  fi
done

for target_config in \
  module.prop \
  config.json \
  online.conf \
  status_v2.json \
  checksums.manifest \
  checksums.sig \
  device.id
do
  if [ -f "$MODPATH/$target_config" ]; then
    chmod 0644 "$MODPATH/$target_config" 2>/dev/null
  fi
done

if [ -f "$MODPATH/zygisk/arm64-v8a.so" ]; then
  chmod 0644 "$MODPATH/zygisk/arm64-v8a.so" 2>/dev/null
else
  log_fail "ARM64 Zygisk library is missing."
fi

if [ -f "$MODPATH/bin/kabirctl" ]; then
  chmod 0755 "$MODPATH/bin/kabirctl" 2>/dev/null
else
  log_fail "Native license helper is missing."
fi

log_status "Applying mandatory SELinux security contexts..."

find "$MODPATH" -type f 2>/dev/null |
while IFS= read -r active_file; do
  chcon u:object_r:system_file:s0 \
    "$active_file" 2>/dev/null
done

log_status "Initializing online serial license..."

rm -f \
  "$MODPATH/license.jwt" \
  "$MODPATH/license.jwt.tmp" \
  "$MODPATH/lease_v2.jwt" \
  "$MODPATH/lease_v2.jwt.tmp" 2>/dev/null

log_status "Running background cleanup routines..."

rm -rf \
  "$MODPATH/system/etc/sysconfig" \
  "$MODPATH/system/product/etc/sysconfig" 2>/dev/null

find "$MODPATH" \
  -mindepth 1 \
  -type d \
  -empty \
  -delete 2>/dev/null

ui_print " "

log_ok "Installation phase completed successfully!"
log_status "Platform configured for ARM64 spoofing deployment."
log_status "Reboot the device to activate KABIR X."

show_footer

sleep 2

WHATSAPP_NUMBER="0545191150"
THANK_MESSAGE="Hello, I want access of Kabir-X INJECTION Module%0ADevice ID: $REAL_SERIAL"
am start -a android.intent.action.VIEW -d "https://wa.me/$WHATSAPP_NUMBER?text=$THANK_MESSAGE" >/dev/null 2>&1