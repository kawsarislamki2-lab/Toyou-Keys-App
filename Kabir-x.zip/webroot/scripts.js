const shell = (cmd) => new Promise((res, rej) => {
  const cb = `cb_${Date.now()}_${Math.random().toString(36).substr(2,5)}`;
  window[cb] = (err, out) => { delete window[cb]; err===0?res(out||''):rej(out||`err:${err}`); };
  if(typeof ksu!=='undefined'&&ksu.exec) ksu.exec(cmd,'{}',cb);
  else res('DEMO_MODE');
});

const CONFIG  = '/data/adb/modules/kabir-spoof/config.json';
const STATUS_PATH = '/data/adb/modules/kabir-spoof/status_v2.json';
const SERIAL_PATH = '/data/adb/modules/kabir-spoof/device.serial';
const SERVICE_V2 = '/data/adb/modules/kabir-spoof/service_v2.sh';
let STATE = {
  config:{cpu_spoof:{blacklist:[],cpu_only_packages:[]},active_injections:{}},
  deviceDb:[],
  selectedIdx:0,
  logRunning:false,
  logTimer:null,
  logSeen:new Set(),
  serial:''
};

const EXT = {
  'Nokia':     [{m:'HMD Global',mod:'Nokia G42 5G',d:'IRM_sprout',p:'IRM'},{m:'HMD Global',mod:'Nokia XR21',d:'SQTR_sprout',p:'SQTR'},{m:'HMD Global',mod:'Nokia X30 5G',d:'SPX_sprout',p:'SPX'},{m:'HMD Global',mod:'Nokia G60 5G',d:'RDR_sprout',p:'RDR'},{m:'HMD Global',mod:'Nokia G22',d:'RG2',p:'RG2'},{m:'HMD Global',mod:'Nokia C32',d:'NC3',p:'NC3'}],
  'Motorola':  [{m:'motorola',mod:'XT2351-1',d:'rtwo',p:'rtwo_g'},{m:'motorola',mod:'XT2301-5',d:'eqs',p:'eqs_g'},{m:'motorola',mod:'XT2311-1',d:'hiphala',p:'hiphala'},{m:'motorola',mod:'XT2451-3',d:'fogo',p:'fogo_g'},{m:'motorola',mod:'XT2429-1',d:'mristretto',p:'mristretto_g'},{m:'motorola',mod:'XT2363-2',d:'bronco',p:'bronco_g'},{m:'motorola',mod:'XT2343-5',d:'devon',p:'devon_g'}],
  'Google':    [{m:'Google',mod:'Pixel 7 Pro',d:'cheetah',p:'cheetah'},{m:'Google',mod:'Pixel 9',d:'caiman',p:'caiman'},{m:'Google',mod:'Pixel 7a',d:'lynx',p:'lynx'},{m:'Google',mod:'Pixel 8 Pro',d:'husky',p:'husky'},{m:'Google',mod:'Pixel 9 Pro',d:'caiman',p:'caiman'},{m:'Google',mod:'Pixel 9 Pro XL',d:'komodo',p:'komodo'},{m:'Google',mod:'Pixel 8',d:'shiba',p:'shiba'},{m:'Google',mod:'Pixel 8a',d:'akita',p:'akita'},{m:'Google',mod:'Pixel Fold',d:'felix',p:'felix'}],
  'Infinix':   [{m:'Infinix',mod:'X6860',d:'X6860',p:'X6860'},{m:'Infinix',mod:'X6851P',d:'X6851P',p:'X6851P'},{m:'Infinix',mod:'X6837',d:'X6837',p:'X6837'},{m:'Infinix',mod:'X6871',d:'X6871',p:'X6871'},{m:'Infinix',mod:'X6883',d:'X6883',p:'X6883'},{m:'Infinix',mod:'X6725D',d:'X6725D',p:'X6725D'},{m:'Infinix',mod:'X6739',d:'X6739',p:'X6739'}],
  'TECNO':     [{m:'TECNO',mod:'AD10',d:'AD10',p:'AD10'},{m:'TECNO',mod:'CL9',d:'CL9',p:'CL9'},{m:'TECNO',mod:'KJ7',d:'KJ7',p:'KJ7'},{m:'TECNO',mod:'LI9',d:'LI9',p:'LI9'},{m:'TECNO',mod:'CK9n',d:'CK9n',p:'CK9n'},{m:'TECNO',mod:'BG6',d:'BG6',p:'BG6'},{m:'TECNO',mod:'CL8',d:'CL8',p:'CL8'}],
  'Sharp':     [{m:'SHARP',mod:'SH-52E',d:'SH-52E',p:'SH52E'},{m:'SHARP',mod:'SH-53E',d:'SH-53E',p:'SH53E'},{m:'SHARP',mod:'SH-51E',d:'SH-51E',p:'SH51E'},{m:'SHARP',mod:'A302SH',d:'A302SH',p:'A302SH'}],
  'Fairphone': [{m:'Fairphone',mod:'FP5',d:'FP5',p:'FP5'},{m:'Fairphone',mod:'FP4',d:'FP4',p:'FP4'},{m:'Fairphone',mod:'FP6',d:'FP6',p:'FP6'}],
  'itel':      [{m:'itel',mod:'S661LPN',d:'S661LPN',p:'S661LPN'},{m:'itel',mod:'A70',d:'A70',p:'A70'},{m:'itel',mod:'P55 5G',d:'itel_P661N',p:'itel_P661N'},{m:'itel',mod:'S665LP',d:'S665LP',p:'S665LP'}],
  'BlackShark':[{m:'Black Shark',mod:'SHARK PRS-H0',d:'SHARK PRS-H0',p:'PRS'},{m:'Black Shark',mod:'SHARK PRS-A0',d:'SHARK PRS-A0',p:'PRS'},{m:'Black Shark',mod:'SHARK KTUS-H0',d:'SHARK KTUS-H0',p:'KTUS'}],
  'Meizu':     [{m:'Meizu',mod:'M6782H',d:'meizu21pro',p:'meizu21pro'},{m:'Meizu',mod:'M6782M',d:'meizu21note',p:'meizu21note'},{m:'Meizu',mod:'M3691',d:'meizu20',p:'meizu20'},{m:'Meizu',mod:'M551H',d:'meizu21',p:'meizu21'}],
  'Lava':      [{m:'Lava',mod:'L6820',d:'L6820',p:'L6820'},{m:'Lava',mod:'BLAZE2',d:'BLAZE2',p:'BLAZE2'},{m:'Lava',mod:'AGNI2',d:'AGNI2',p:'AGNI2'},{m:'Lava',mod:'L6821',d:'L6821',p:'L6821'}],
  'Micromax':  [{m:'Micromax',mod:'MMXIN2',d:'MMXIN2',p:'MMXIN2'},{m:'Micromax',mod:'E7746',d:'E7746',p:'E7746'},{m:'Micromax',mod:'IN2c',d:'IN2c',p:'IN2c'}],
  'TCL':       [{m:'TCL',mod:'T612B',d:'TCL_T612B',p:'T612B_JP'},{m:'TCL',mod:'T610K',d:'TCL_T610K',p:'T610K_EU'},{m:'TCL',mod:'T767H',d:'TCL_T767H',p:'T767H'},{m:'TCL',mod:'T811H',d:'TCL_T811H',p:'T811H'}],
  'Wiko':      [{m:'Wiko',mod:'wiko_hi_enjoy70pro',d:'wiko_hi_enjoy70pro',p:'wiko_hi_enjoy70pro'},{m:'Wiko',mod:'W-V770-EEA',d:'W-V770',p:'W-V770'},{m:'Wiko',mod:'wiko_hi_enjoy60',d:'wiko_hi_enjoy60',p:'wiko_hi_enjoy60'}],
  'HTC':       [{m:'HTC',mod:'2Q9E100',d:'mtkmt6985',p:'htc_mtkmt6985'},{m:'HTC',mod:'2QBK100',d:'htc_u24pro',p:'htc_u24pro'},{m:'HTC',mod:'2PZF100',d:'htc_desire22pro',p:'htc_desire22pro'}],
  'BLU':       [{m:'BLU',mod:'G0390WW',d:'G0390WW',p:'G0390WW'},{m:'BLU',mod:'G91s',d:'G91s',p:'G91s'},{m:'BLU',mod:'G93',d:'G93',p:'G93'},{m:'BLU',mod:'G53',d:'G53',p:'G53'}],
  'HONOR':     [{m:'HONOR',mod:'ALI-AN00',d:'ALI-AN00',p:'ALI-AN00'},{m:'HONOR',mod:'REA-NX9',d:'REA-NX9',p:'REA-NX9'},{m:'HONOR',mod:'BVL-AN16',d:'BVL-AN16',p:'BVL-AN16'},{m:'HONOR',mod:'PGT-N19',d:'PGT-N19',p:'PGT-N19'},{m:'HONOR',mod:'FCP-AN10',d:'FCP-AN10',p:'FCP-AN10'},{m:'HONOR',mod:'CMA-LX1',d:'CMA-LX1',p:'CMA-LX1'}],
  'Huawei':    [{m:'HUAWEI',mod:'ALN-AL10',d:'ALN-AL10',p:'ALN-AL10'},{m:'HUAWEI',mod:'BVD-AL10',d:'BVD-AL10',p:'BVD-AL10'},{m:'HUAWEI',mod:'BRA-AL00',d:'BRA-AL00',p:'BRA-AL00'},{m:'HUAWEI',mod:'DCO-AL00',d:'DCO-AL00',p:'DCO-AL00'},{m:'HUAWEI',mod:'PALA-AL00',d:'PALA-AL00',p:'PALA-AL00'}],
  'OnePlus':   [{m:'OnePlus',mod:'CPH2581',d:'OP594DL1',p:'CPH2581'},{m:'OnePlus',mod:'CPH2573',d:'OP5953L1',p:'CPH2573'},{m:'OnePlus',mod:'PJD110',d:'OP5954L1',p:'PJD110'},{m:'OnePlus',mod:'CPH2449',d:'OP5552L1',p:'CPH2449'},{m:'OnePlus',mod:'CPH2609',d:'OP5959L1',p:'CPH2609'},{m:'OnePlus',mod:'CPH2655',d:'OP5G2L1',p:'CPH2655'}],
  'Nothing':   [{m:'Nothing',mod:'A142P',d:'Pacman',p:'Pacman'},{m:'Nothing',mod:'A065',d:'Pong',p:'Pong'},{m:'Nothing',mod:'A063',d:'Spacewar',p:'Spacewar'},{m:'Nothing',mod:'A059',d:'Pong',p:'Pong'},{m:'Nothing',mod:'A015',d:'Tetris',p:'Tetris'}],
  'Sony':      [{m:'Sony',mod:'XQ-EC54',d:'pdx-237',p:'J9110'},{m:'Sony',mod:'XQ-ES54',d:'pdx-239',p:'J8210'},{m:'Sony',mod:'XQ-ES72',d:'pdx-241',p:'I3113'},{m:'Sony',mod:'XQ-DE54',d:'pdx-234',p:'XQ-DE54'},{m:'Sony',mod:'XQ-CT54',d:'pdx-223',p:'XQ-CT54'}],
  'ZTE':       [{m:'ZTE',mod:'ZTE 9046N',d:'jaguar',p:'jaguar'},{m:'ZTE',mod:'ZTE A2024G',d:'gemini',p:'gemini'},{m:'ZTE',mod:'ZTE 8046',d:'libra',p:'libra'},{m:'ZTE',mod:'ZTE A2025',d:'aquila',p:'aquila'}],
  'Nubia':     [{m:'nubia',mod:'NX721J',d:'NX721J',p:'NX721J'},{m:'nubia',mod:'NX724J',d:'NX724J',p:'NX724J'},{m:'nubia',mod:'NX729J',d:'NX729J',p:'NX729J'},{m:'nubia',mod:'NX712J',d:'NX712J',p:'NX712J'}],
  'Poco':      [{m:'Xiaomi',mod:'2311DRK48G',d:'aurora',p:'aurora_global'},{m:'Xiaomi',mod:'24069PC21G',d:'peridot',p:'peridot_global'},{m:'Xiaomi',mod:'23013PC75G',d:'munch',p:'munch_global'},{m:'Xiaomi',mod:'24094RAD4G',d:'chenfeng',p:'chenfeng_global'}],
  'iQOO':      [{m:'vivo',mod:'V2324A',d:'V2324A',p:'V2324A'},{m:'vivo',mod:'I2301',d:'I2301',p:'I2301'},{m:'vivo',mod:'V2415A',d:'V2415A',p:'V2415A'},{m:'vivo',mod:'I2017',d:'I2017',p:'I2017'}],
  'Redmagic':  [{m:'ZTE',mod:'NX769J',d:'NX769J',p:'NX769J'},{m:'ZTE',mod:'NX779J',d:'NX779J',p:'NX779J'},{m:'ZTE',mod:'NX759J',d:'NX759J',p:'NX759J'}],
  'Ulefone':   [{m:'Ulefone',mod:'Armor 24',d:'Armor_24',p:'Armor_24'},{m:'Ulefone',mod:'Power Armor 19',d:'Power_Armor_19',p:'Power_Armor_19'},{m:'Ulefone',mod:'Note 16 Pro',d:'Note_16_Pro',p:'Note_16_Pro'},{m:'Ulefone',mod:'Armor 27',d:'Armor_27',p:'Armor_27'}],
  'Doogee':    [{m:'DOOGEE',mod:'S110',d:'S110',p:'S110'},{m:'DOOGEE',mod:'V30T',d:'V30T',p:'V30T'},{m:'DOOGEE',mod:'N50 Pro',d:'N50_Pro',p:'N50_Pro'},{m:'DOOGEE',mod:'S118',d:'S118',p:'S118'}],
  'Cubot':     [{m:'CUBOT',mod:'KingKong 9',d:'KingKong_9',p:'KingKong_9'},{m:'CUBOT',mod:'P80',d:'P80',p:'P80'},{m:'CUBOT',mod:'X70',d:'X70',p:'X70'},{m:'CUBOT',mod:'KingKong Star',d:'KingKong_Star',p:'KingKong_Star'}],
  'Umidigi':   [{m:'UMIDIGI',mod:'G9 5G',d:'G9_5G',p:'G9_5G'},{m:'UMIDIGI',mod:'A15C',d:'A15C',p:'A15C'},{m:'UMIDIGI',mod:'Bison X20',d:'Bison_X20',p:'Bison_X20'},{m:'UMIDIGI',mod:'G5 Mecha',d:'G5_Mecha',p:'G5_Mecha'}],
};

const ALL_BRANDS=['Samsung','Xiaomi','Oppo','Vivo','Realme','Asus',...Object.keys(EXT)].sort();
const BRAND_SEL=document.getElementById('sel-brand');
ALL_BRANDS.forEach(b=>{const o=document.createElement('option');o.value=b;o.textContent=b;BRAND_SEL.appendChild(o);});

// Multiple realistic SoC options per brand — one picked at random per device
const CPU_POOL={
  samsung:[
    {abi:'arm64-v8a',platform:'exynos2200',hardware:'exynos2200'},
    {abi:'arm64-v8a',platform:'exynos2400',hardware:'exynos2400'},
    {abi:'arm64-v8a',platform:'exynos1380',hardware:'s5e8835'},
    {abi:'arm64-v8a',platform:'sm8650',hardware:'qcom'},
    {abi:'arm64-v8a',platform:'sm8750',hardware:'qcom'},
    {abi:'arm64-v8a',platform:'mt6877',hardware:'mt6877'}],
  google:[
    {abi:'arm64-v8a',platform:'tensor_g4',hardware:'tensor'},
    {abi:'arm64-v8a',platform:'gs201',hardware:'tensor'},
    {abi:'arm64-v8a',platform:'zuma',hardware:'tensor'},
    {abi:'arm64-v8a',platform:'zumapro',hardware:'tensor'}],
  motorola:[
    {abi:'arm64-v8a',platform:'mt6985',hardware:'mt6985'},
    {abi:'arm64-v8a',platform:'sm7475',hardware:'qcom'},
    {abi:'arm64-v8a',platform:'sm6375',hardware:'qcom'},
    {abi:'arm64-v8a',platform:'mt6833',hardware:'mt6833'}],
  huawei:[
    {abi:'arm64-v8a',platform:'kirin9000',hardware:'kirin990'},
    {abi:'arm64-v8a',platform:'kirin9000s',hardware:'kirin9000s'},
    {abi:'arm64-v8a',platform:'kirin9010',hardware:'kirin9010'}],
  honor:[
    {abi:'arm64-v8a',platform:'sm8650',hardware:'qcom'},
    {abi:'arm64-v8a',platform:'kirin9000',hardware:'kirin'},
    {abi:'arm64-v8a',platform:'mt6886',hardware:'mt6886'}],
  oneplus:[
    {abi:'arm64-v8a',platform:'sm8650',hardware:'qcom'},
    {abi:'arm64-v8a',platform:'sm8750',hardware:'qcom'},
    {abi:'arm64-v8a',platform:'mt6989',hardware:'mt6989'}],
  xiaomi:[
    {abi:'arm64-v8a',platform:'sm8650',hardware:'qcom'},
    {abi:'arm64-v8a',platform:'sm8635',hardware:'qcom'},
    {abi:'arm64-v8a',platform:'mt6985',hardware:'mt6985'},
    {abi:'arm64-v8a',platform:'mt6989',hardware:'mt6989'}],
  oppo:[
    {abi:'arm64-v8a',platform:'mt6985',hardware:'mt6985'},
    {abi:'arm64-v8a',platform:'sm7550',hardware:'qcom'},
    {abi:'arm64-v8a',platform:'sm8650',hardware:'qcom'}],
  realme:[
    {abi:'arm64-v8a',platform:'mt6886',hardware:'mt6886'},
    {abi:'arm64-v8a',platform:'sm7435',hardware:'qcom'},
    {abi:'arm64-v8a',platform:'mt6985',hardware:'mt6985'}],
  infinix:[
    {abi:'arm64-v8a',platform:'mt6789',hardware:'mt6789'},
    {abi:'arm64-v8a',platform:'mt6835',hardware:'mt6835'},
    {abi:'arm64-v8a',platform:'mt6769',hardware:'mt6769'}],
  tecno:[
    {abi:'arm64-v8a',platform:'mt6789',hardware:'mt6789'},
    {abi:'arm64-v8a',platform:'mt6835',hardware:'mt6835'},
    {abi:'arm64-v8a',platform:'mt6768',hardware:'mt6768'}],
  itel:[
    {abi:'arm64-v8a',platform:'mt6761',hardware:'mt6761'},
    {abi:'arm64-v8a',platform:'mt6765',hardware:'mt6765'}],
  zte:[
    {abi:'arm64-v8a',platform:'mt6877',hardware:'mt6877'},
    {abi:'arm64-v8a',platform:'sm6375',hardware:'qcom'},
    {abi:'arm64-v8a',platform:'sm7325',hardware:'qcom'}],
  nubia:[
    {abi:'arm64-v8a',platform:'sm8650',hardware:'qcom'},
    {abi:'arm64-v8a',platform:'sm8750',hardware:'qcom'},
    {abi:'arm64-v8a',platform:'sm8550',hardware:'qcom'}],
  vivo:[
    {abi:'arm64-v8a',platform:'mt6985',hardware:'mt6985'},
    {abi:'arm64-v8a',platform:'sm8635',hardware:'qcom'},
    {abi:'arm64-v8a',platform:'sm8650',hardware:'qcom'},
    {abi:'arm64-v8a',platform:'mt6878',hardware:'mt6878'}],
  ulefone:[
    {abi:'arm64-v8a',platform:'mt6789',hardware:'mt6789'},
    {abi:'arm64-v8a',platform:'mt6835',hardware:'mt6835'},
    {abi:'arm64-v8a',platform:'mt6833',hardware:'mt6833'}],
  doogee:[
    {abi:'arm64-v8a',platform:'mt6789',hardware:'mt6789'},
    {abi:'arm64-v8a',platform:'mt6769',hardware:'mt6769'},
    {abi:'arm64-v8a',platform:'mt6835',hardware:'mt6835'}],
  cubot:[
    {abi:'arm64-v8a',platform:'mt6769',hardware:'mt6769'},
    {abi:'arm64-v8a',platform:'mt6761',hardware:'mt6761'}],
  umidigi:[
    {abi:'arm64-v8a',platform:'mt6789',hardware:'mt6789'},
    {abi:'arm64-v8a',platform:'mt6833',hardware:'mt6833'}],
  default:[
    {abi:'arm64-v8a',platform:'qcom',hardware:'qcom'},
    {abi:'arm64-v8a',platform:'sm8650',hardware:'qcom'},
    {abi:'arm64-v8a',platform:'mt6985',hardware:'mt6985'},
    {abi:'arm64-v8a',platform:'sm7550',hardware:'qcom'}]
};
function pickCpu(fpb){
  const pool=CPU_POOL[String(fpb).toLowerCase()]||CPU_POOL['default'];
  return pool[Math.floor(Math.random()*pool.length)];
}

// Realistic SIM operators (mcc,mnc,operator id,name,iso country)
const SIM_OPS=[
  {mcc:'418',mnc:'20',name:'Zain KW',iso:'kw'},
  {mcc:'419',mnc:'02',name:'Zain',iso:'kw'},
  {mcc:'419',mnc:'03',name:'Ooredoo',iso:'kw'},
  {mcc:'419',mnc:'04',name:'STC',iso:'kw'},
  {mcc:'425',mnc:'01',name:'Orange',iso:'il'},
  {mcc:'310',mnc:'260',name:'T-Mobile',iso:'us'},
  {mcc:'234',mnc:'15',name:'Vodafone UK',iso:'gb'},
  {mcc:'410',mnc:'01',name:'Jazz',iso:'pk'},
  {mcc:'470',mnc:'01',name:'Grameenphone',iso:'bd'},
  {mcc:'404',mnc:'45',name:'Airtel',iso:'in'}
];
// Luhn check digit for IMEI (14 digits -> 15th)
function luhn(num){
  let sum=0,alt=false;
  for(let i=num.length-1;i>=0;i--){
    let d=parseInt(num[i],10);
    if(alt){d*=2;if(d>9)d-=9;}
    sum+=d;alt=!alt;
  }
  return (10-(sum%10))%10;
}
function genSim(ri,rs){
  const op=SIM_OPS[Math.floor(Math.random()*SIM_OPS.length)];
  const tac=rs(8,'0123456789');           // type allocation code
  const snr=rs(6,'0123456789');            // serial
  const imei14=tac+snr;
  const imei=imei14+luhn(imei14);
  const msin=rs(10,'0123456789');
  const imsi=op.mcc+op.mnc.padStart(2,'0')+msin;
  // ICCID: 89 + country + issuer + account, 19-20 digits with luhn
  const iccBase='89'+op.mcc.slice(0,2)+rs(13,'0123456789');
  const iccid=iccBase+luhn(iccBase);
  const phone='+'+op.mcc.slice(0,3)+rs(8,'0123456789');
  return {
    sim_imsi:imsi,
    sim_imei:imei,
    sim_iccid:iccid,
    sim_phone:phone,
    sim_operator:op.mcc+op.mnc.padStart(2,'0'),
    sim_country:op.iso,
    sim_operator_name:op.name
  };
}
function genPatch(ri){
  const y=ri(2023,2026);
  const m=String(ri(1,12)).padStart(2,'0');
  return `${y}-${m}-05`;
}

function generateDevices(){
  const brand=BRAND_SEL.value;
  const rnd=a=>a[Math.floor(Math.random()*a.length)];
  const ri=(a,b)=>Math.floor(Math.random()*(b-a+1))+a;
  const rs=(n,c)=>Array.from({length:n},()=>c[Math.floor(Math.random()*c.length)]).join('');
const os=[{os:'9',sdk:28},{os:'10',sdk:29},
{os:'11',sdk:30},{os:'12',sdk:31},{os:'12L',sdk:32},
{os:'13',sdk:33},{os:'14',sdk:34},{os:'15',sdk:35},{os:'16',sdk:36}];
  const btn=document.getElementById('btn-generate');
  btn.textContent='Generating...'; btn.disabled=true;
  setTimeout(()=>{
    const db=[];
    for(let i=0;i<300;i++){
      const o=rnd(os);
      const first=o.sdk>=36?'B':o.sdk>=35?'A':o.sdk>=34?'U':o.sdk===33?'T':o.sdk===32?'S':o.sdk===31?'Q':o.sdk===30?'P':o.sdk===29?'O':o.sdk===28?'N':'R';
      const bid=`${first}${rnd(['P','Q','R'])}${ri(1,3)}${rnd(['A','B','C'])}.${ri(20,26)}${String(ri(1,12)).padStart(2,'0')}${String(ri(1,28)).padStart(2,'0')}.${String(ri(1,999)).padStart(3,'0')}`;
      const inc=rs(6,'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789');
      let mfr=brand,model,device,product,fpb=brand.toLowerCase();
      if(brand==='Samsung'){const s=rnd(['S','A','M','F','Z']);const g=ri(11,64);const v=rnd(['B','E','F','N','0']);model=`SM-${s}${g}${v}`;device=`${s.toLowerCase()}${g}xsq`;product=device;fpb='samsung';mfr='samsung';}
      else if(brand==='Xiaomi'){model=`${ri(20,24)}${ri(10,12)}${ri(1000,9999)}${rnd(['G','C','I'])}`;device=rnd(['alioth','vangogh','munch','rubens','thor']);product=device;fpb='xiaomi';}
      else if(brand==='Oppo'){model=`CPH${ri(2000,2600)}`;device=`OP${ri(4000,5999)}L1`;product=device;fpb='oppo';}
      else if(brand==='Vivo'){model=`V${ri(2000,2400)}`;device=`PD${ri(2000,2300)}`;product=device;fpb='vivo';}
      else if(brand==='Realme'){model=`RMX${ri(2000,3999)}`;device=`RE${ri(5000,5999)}`;product=device;fpb='realme';}
      else if(brand==='Asus'){model=`ASUS_I00${ri(1,9)}D`;device=`ASUS_I00${ri(1,9)}`;product=device;fpb='asus';}
      else if(EXT[brand]){const t=rnd(EXT[brand]);mfr=t.m;model=t.mod;device=t.d;product=t.p;
        if(['Google','Motorola'].includes(brand))fpb=brand.toLowerCase();
        else if(['HTC','TECNO','HONOR','BLU','HUAWEI'].includes(brand))fpb=brand.toUpperCase();
        else if(brand==='OnePlus')fpb='OnePlus';
        else if(brand==='Poco')fpb='xiaomi';
        else if(brand==='iQOO')fpb='vivo';
        else if(brand==='Redmagic')fpb='nubia';
        else fpb=t.m.toLowerCase();}
      const cpu=pickCpu(fpb);
      const security_patch=genPatch(ri);
      const bootloader=`${(device||product||'BL').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,6)||'BL'}${ri(1,9)}.${String(ri(0,9999)).padStart(4,'0')}.${ri(1,12)}`;
      const serial=rs(ri(8,11),'0123456789ABCDEFGHJKLMNPQRSTUVWXYZ');
      const android_id=rs(16,'0123456789abcdef');       // SSAID (64-bit hex) — for reinstall consistency
      const sim=genSim(ri,rs);
      db.push({brand,manufacturer:mfr,model,device,product,fingerprint:`${fpb}/${product}/${device}:${o.os}/${bid}/${inc}:user/release-keys`,android_version:o.os,sdk_int:o.sdk,build_id:bid,security_patch,bootloader,serial,android_id,cpu_abi:cpu.abi,cpu_platform:cpu.platform,cpu_hardware:cpu.hardware,...sim,_ui_profile:`${brand} - ${model}`});
    }
    STATE.deviceDb=db; STATE.selectedIdx=0;
    renderDeviceList();
    document.getElementById('device-list-wrap').style.display='block';
    document.getElementById('db-count').textContent=`300 Profiles — ${brand}`;
    document.getElementById('btn-inject').disabled=false;
    updateSelLabel();
    btn.textContent=`Regenerate ${brand}`; btn.disabled=false;
    addLog(`Generated 300 ${brand} profiles`,'ok');
  },100);
}

function renderDeviceList(){
  const list=document.getElementById('device-list');
  list.innerHTML=STATE.deviceDb.map((d,i)=>`
    <div class="device-option ${i===STATE.selectedIdx?'selected':''}" onclick="selectDevice(${i})">
      <div>
        <div class="dev-name">${d.model}</div>
        <div class="dev-sub">Android ${d.android_version} · ${d.cpu_platform} · ${d.cpu_hardware}</div>
      </div>
      <span class="check">✓</span>
    </div>
  `).join('');
}

function selectDevice(i){
  STATE.selectedIdx=i;
  renderDeviceList();
  updateSelLabel();
}

function updateSelLabel(){
  const d=STATE.deviceDb[STATE.selectedIdx];
  document.getElementById('sel-device-label').textContent=d?d._ui_profile:'No device selected';
  document.getElementById('sel-device-label').style.color=d?'var(--text)':'var(--muted)';
}

async function injectApp(){
  const pkg=document.getElementById('sel-app').value;
  const d=STATE.deviceDb[STATE.selectedIdx];
  if(!d){addLog('Generate devices first','warn');return;}
  STATE.config.active_injections[pkg]={enabled:true,mode:'with_cpu',device_info:{...d}};
  await autoSave();
  renderActive();
  await shell(`am force-stop ${pkg}`).catch(()=>{});
  addLog(`Protection active → ${APP_NAMES[pkg]||pkg}`,'ok');
}

async function removeApp(pkg){
  delete STATE.config.active_injections[pkg];
  await autoSave();
  renderActive();
  await shell(`am force-stop ${pkg}`).catch(()=>{});
  addLog(`Removed: ${APP_NAMES[pkg]||pkg}`,'warn');
}

async function autoSave(){
  setSaveStatus('saving');
  const str=JSON.stringify(STATE.config,null,2);
  const temp=CONFIG+'.tmp';
  try{
    // base64-encode (UTF-8 safe) so no heredoc/newline/quote issues via ksu.exec
    const b64=btoa(unescape(encodeURIComponent(str)));
    await shell(
      `mkdir -p /data/adb/modules/kabir-spoof; echo '${b64}' | base64 -d > "${temp}" && chmod 0644 "${temp}" && mv -f "${temp}" "${CONFIG}" && chcon u:object_r:system_file:s0 "${CONFIG}" 2>/dev/null || true`
    );
    const saved=await shell(`cat "${CONFIG}" 2>/dev/null`);
    JSON.parse(saved);
    setSaveStatus('saved');
    setTimeout(()=>setSaveStatus(''),2000);
  }catch(e){
    setSaveStatus('error');
    addLog('Config save failed','fail');
  }
}

function setSaveStatus(s){
  const el=document.getElementById('save-indicator')||{style:{},textContent:''};
  if(s==='saving'){el.style.color='var(--warn)';el.textContent='Saving...';}
  else if(s==='saved'){el.style.color='var(--primary)';el.textContent='Saved';}
  else if(s==='error'){el.style.color='var(--danger)';el.textContent='Error';}
  else el.textContent='';
}

const APP_NAMES = {
  'com.logistics.rider.talabat': 'Talabat Rider',
  'com.logistics.rider.hungerstation': 'HungerStation Rider',
  'com.logistics.rider.foodpanda': 'Foodpanda Rider',
  'com.android.vending': 'Play Store',
  'com.google.android.gms': 'Google Play Services',
  'com.google.android.gsf': 'Google Services Framework'
};

const APP_COLORS = {
  'com.logistics.rider.talabat': '#FF6B35',
  'com.logistics.rider.hungerstation': '#FF9500',
  'com.logistics.rider.foodpanda': '#D70F64',
  'com.android.vending': '#34A853',
  'com.google.android.gms': '#4285F4',
  'com.google.android.gsf': '#FBBC05'
};

function renderActive(){
  const el=document.getElementById('active-list');
  const items=Object.entries(STATE.config.active_injections||{});
  if(!items.length){el.innerHTML='<div class="empty-state">No active injections</div>';return;}
  el.innerHTML=items.map(([pkg,data])=>`
    <div class="row">
      <div class="row-dot" style="background:${APP_COLORS[pkg]||'#555'}"></div>
      <div style="flex:1">
        <div class="row-title">${APP_NAMES[pkg]||pkg}</div>
        <div class="row-sub">${data.device_info?._ui_profile||'Active'}</div>
        <div class="row-sub muted">${pkg}</div>
      </div>
      <button class="btn btn-danger btn-sm" onclick="removeApp('${pkg}')">Remove</button>
    </div>
  `).join('');
}

function addLog(msg,type='ok'){
  const area=document.getElementById('log-area');
  const empty=area.querySelector('.log-empty');
  if(empty) empty.remove();
  const t=new Date().toLocaleTimeString();
  const row=document.createElement('div');
  row.className='log-row';
  row.innerHTML=`<span class="log-time">${t}</span><span class="log-badge log-${type}">${type==='ok'?'OK':type==='warn'?'WARN':'FAIL'}</span><span class="log-msg"></span>`;
  row.querySelector('.log-msg').textContent=String(msg);
  area.appendChild(row);
  while(area.children.length>200) area.removeChild(area.firstChild);
  area.scrollTop=area.scrollHeight;
}

function clearLog(){
  document.getElementById('log-area').innerHTML='<div class="log-empty">Tap Start to view status</div>';
  STATE.logSeen.clear();
}

async function toggleLog(){
  const btn=document.getElementById('btn-log');
  if(!STATE.logRunning){
    STATE.logRunning=true;
    btn.textContent='Stop';
    btn.style.background='var(--danger)';
    addLog('Monitoring started','ok');
    const tick=async()=>{
      if(!STATE.logRunning) return;
      try{
        const data=await shell("logcat -d -v time -s KabirSpoof 2>/dev/null | tail -80");
        if(data&&data.trim()&&data!=='DEMO_MODE'){
          data.split('\n').filter(l=>l.trim()).forEach(line=>{
            const key=line.trim();
            if(STATE.logSeen.has(key)) return;
            STATE.logSeen.add(key);
            if(STATE.logSeen.size>500){
              STATE.logSeen=new Set(Array.from(STATE.logSeen).slice(-250));
            }
            const msg=line.replace(/.*KabirSpoof:\s*/,'').trim();
            if(!msg) return;
            const lower=msg.toLowerCase();
            const type=lower.includes('invalid')||lower.includes('fail')||lower.includes('error')||lower.includes('expired')?'fail':lower.includes('warn')?'warn':'ok';
            addLog(msg,type);
          });
        }
      }catch(e){
        addLog('Log read failed','fail');
      }
      STATE.logTimer=setTimeout(tick,2000);
    };
    tick();
  }else{
    STATE.logRunning=false;
    clearTimeout(STATE.logTimer);
    btn.textContent='Start';
    btn.style.background='var(--info)';
    addLog('Monitoring stopped','warn');
  }
}

function setLicenseUi(status,data={}){
  const badge=document.getElementById('lic-badge');
  const statusText=document.getElementById('lic-status-text');
  const daysEl=document.getElementById('lic-days');
  const expiryEl=document.getElementById('lic-expiry');
  const lastEl=document.getElementById('lic-last-check');
  const messageEl=document.getElementById('lic-message');

  const normalized=String(status||'not_activated').toLowerCase();
  const expiresAt=Number(data.expiresAt||0);
  const now=Math.floor(Date.now()/1000);
  const remaining=expiresAt>now?Math.ceil((expiresAt-now)/86400):0;

  daysEl.textContent=expiresAt?String(remaining):'--';
  expiryEl.textContent=expiresAt?new Date(expiresAt*1000).toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'}):'--';
  lastEl.textContent=data.lastCheck?new Date(Number(data.lastCheck)*1000).toLocaleString():'--';
  messageEl.textContent=data.message||'Send this serial to Admin for activation.';

  if(normalized==='active'&&expiresAt>now){
    badge.className='lic-badge lic-valid';
    badge.textContent=`Active · ${remaining}d`;
    statusText.textContent='ACTIVE';
    statusText.className='lic-val ok';
  }else if(normalized==='pending'){
    badge.className='lic-badge lic-none';
    badge.textContent='Pending';
    statusText.textContent='PENDING';
    statusText.className='lic-val warn';
  }else if(normalized==='expired'){
    badge.className='lic-badge lic-expired';
    badge.textContent='Expired';
    statusText.textContent='EXPIRED';
    statusText.className='lic-val warn';
    daysEl.textContent='0';
  }else if(normalized==='revoked'){
    badge.className='lic-badge lic-expired';
    badge.textContent='Revoked';
    statusText.textContent='REVOKED';
    statusText.className='lic-val warn';
  }else if(normalized==='offline'||normalized==='network_error'){
    badge.className='lic-badge lic-none';
    badge.textContent='Offline';
    statusText.textContent='OFFLINE';
    statusText.className='lic-val warn';
  }else{
    badge.className='lic-badge lic-none';
    badge.textContent='Not Active';
    statusText.textContent='NOT ACTIVATED';
    statusText.className='lic-val warn';
  }
}

async function fetchOnlineLicense(){
  try{
    const serial=(await shell(`cat "${SERIAL_PATH}" 2>/dev/null || true`)).trim();
    STATE.serial=serial&&serial!=='DEMO_MODE'?serial:'';
    document.getElementById('lic-serial').textContent=STATE.serial||'Unavailable';

    const raw=await shell(`cat "${STATUS_PATH}" 2>/dev/null || echo '{}'`);
    const data=JSON.parse(raw&&raw!=='DEMO_MODE'?raw:'{}');
    setLicenseUi(data.status||'not_activated',data);
  }catch(e){
    setLicenseUi('not_activated',{message:'License status unavailable.'});
    addLog('Online license status read failed','fail');
  }
}

async function refreshOnlineLicense(){
  const btn=document.getElementById('btn-refresh-license');
  btn.disabled=true;
  btn.textContent='Checking...';
  try{
    await shell(`sh "${SERVICE_V2}" --once`);
    await fetchOnlineLicense();
    addLog('Online license status refreshed','ok');
  }catch(e){
    await fetchOnlineLicense();
    addLog('Online license refresh failed','fail');
  }finally{
    btn.disabled=false;
    btn.textContent='Refresh Online Status';
  }
}

async function copySerial(){
  const serial=STATE.serial||document.getElementById('lic-serial').textContent.trim();
  if(!serial||serial==='Unavailable'||serial==='--'){
    addLog('Original serial unavailable','fail');
    return;
  }
  try{
    if(navigator.clipboard&&navigator.clipboard.writeText){
      await navigator.clipboard.writeText(serial);
    }else{
      const ta=document.createElement('textarea');
      ta.value=serial;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    }
    addLog('Serial copied','ok');
  }catch(e){
    addLog('Copy failed','fail');
  }
}

function showTab(id,btn){
  document.querySelectorAll('.panel').forEach(p=>p.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(b=>b.classList.remove('active'));
  document.getElementById('panel-'+id).classList.add('active');
  btn.classList.add('active');
}

async function loadConfig(){
  try{
    const data=await shell(`cat "${CONFIG}" 2>/dev/null || echo '{}'`);
    const parsed=JSON.parse(data&&data!=='DEMO_MODE'?data:'{}');
    if(!parsed||typeof parsed!=='object'||Array.isArray(parsed)) throw new Error('invalid root');

    STATE.config=parsed;
    if(!STATE.config.cpu_spoof||typeof STATE.config.cpu_spoof!=='object'){
      STATE.config.cpu_spoof={blacklist:[],cpu_only_packages:[]};
    }
    if(!Array.isArray(STATE.config.cpu_spoof.blacklist)) STATE.config.cpu_spoof.blacklist=[];
    if(!Array.isArray(STATE.config.cpu_spoof.cpu_only_packages)) STATE.config.cpu_spoof.cpu_only_packages=[];
    if(!STATE.config.active_injections||typeof STATE.config.active_injections!=='object'||Array.isArray(STATE.config.active_injections)){
      STATE.config.active_injections={};
    }

    renderActive();
    addLog('Config loaded','ok');
  }catch(e){
    renderActive();
    addLog('Config load failed: invalid JSON','fail');
  }
}

document.addEventListener('DOMContentLoaded',()=>{
  loadConfig();
  fetchOnlineLicense();
  setInterval(fetchOnlineLicense,60000);
});

/* ==================================================================
   PREMIUM ADDITIONS — modals, TEE package selector, device info
   (original functions above are unchanged)
   ================================================================== */
const MODID = 'kabir-spoof';

function openModal(id){document.getElementById(id).classList.add('open'); if(id==='home-modal') loadDeviceInfo();}
function closeModal(id){document.getElementById(id).classList.remove('open');}
function openLink(url){ shell(`am start -a android.intent.action.VIEW -d "${url}"`).catch(()=>{}); }

/* ---- Theme color: Color(hue) + Theme(saturation), AUTO-SAVED ---- */
const HUE_FILE='/data/adb/modules/'+MODID+'/home_hue';
const SAT_FILE='/data/adb/modules/'+MODID+'/home_sat';
function applySwatch(h){ const sw=document.getElementById('hue-swatch'); if(sw) sw.style.background=`hsl(${h},78%,53%)`; }
function setHue(h){
  document.documentElement.style.setProperty('--hue', h);
  applySwatch(h);
  shell(`echo ${h} > "${HUE_FILE}" 2>/dev/null`).catch(()=>{});
  try{ localStorage.setItem('kabirx_hue', h); }catch(e){}
}
function setSat(s){
  document.documentElement.style.setProperty('--sat', s+'%');
  shell(`echo ${s} > "${SAT_FILE}" 2>/dev/null`).catch(()=>{});
  try{ localStorage.setItem('kabirx_sat', s); }catch(e){}
}
function pickHue(h){ setHue(h); const sl=document.getElementById('home-hue'); if(sl) sl.value=h; }
async function loadHomeColor(){
  let h=null, s=null;
  try{ h=localStorage.getItem('kabirx_hue')||h; s=localStorage.getItem('kabirx_sat')||s; }catch(e){}
  try{ const f=(await shell(`cat "${HUE_FILE}" 2>/dev/null || echo ""`)).trim(); if(f&&f!=='DEMO_MODE'&&!isNaN(f)) h=f; }catch(e){}
  try{ const f=(await shell(`cat "${SAT_FILE}" 2>/dev/null || echo ""`)).trim(); if(f&&f!=='DEMO_MODE'&&!isNaN(f)) s=f; }catch(e){}
  if(h&&!isNaN(h)){ document.documentElement.style.setProperty('--hue',h); const sl=document.getElementById('home-hue'); if(sl) sl.value=h; applySwatch(h); }
  if(s&&!isNaN(s)){ document.documentElement.style.setProperty('--sat',s+'%'); const sl=document.getElementById('home-sat'); if(sl) sl.value=s; }
}
loadHomeColor();

/* ---- Device info + installed modules ---- */
async function loadDeviceInfo(){
  const set=(id,v)=>{const el=document.getElementById(id); if(el&&v) el.textContent=v;};
  try{
    const out=await shell('echo "MODEL=$(getprop ro.product.model)"; echo "KERNEL=$(uname -r)"; echo "SDK=$(getprop ro.build.version.sdk)"; echo "REL=$(getprop ro.build.version.release)"; Z=""; for m in zygisksu zygisk_next rezygisk; do if [ -d /data/adb/modules/$m ] && [ ! -f /data/adb/modules/$m/disable ]; then nm=$(grep "^name=" /data/adb/modules/$m/module.prop 2>/dev/null | cut -d= -f2); vv=$(grep "^version=" /data/adb/modules/$m/module.prop 2>/dev/null | cut -d= -f2); Z="$nm $vv"; break; fi; done; echo "ZYGISK=$Z"; MV=$(grep "^version=" /data/adb/modules/'+MODID+'/module.prop 2>/dev/null | cut -d= -f2); MC=$(grep "^versionCode=" /data/adb/modules/'+MODID+'/module.prop 2>/dev/null | cut -d= -f2); echo "MODULE=$MV ($MC)"');
    if(!out || out.trim()==='DEMO_MODE'){
      set('di-model','Samsung SM-A065F'); set('di-kernel','5.10.198-android13');
      set('di-sdk','35 (Android 15)'); set('di-zygisk','ZygiskNext 1.2.4'); set('di-module','9.1 (910)');
      loadModules(); return;
    }
    const map={}; out.split('\n').forEach(l=>{const i=l.indexOf('='); if(i>0) map[l.slice(0,i)]=l.slice(i+1).trim();});
    set('di-model', map.MODEL||'Unknown');
    set('di-kernel', map.KERNEL||'Unknown');
    set('di-sdk', (map.SDK?`${map.SDK}`:'?')+(map.REL?` (Android ${map.REL})`:''));
    set('di-zygisk', map.ZYGISK && map.ZYGISK.trim() ? map.ZYGISK : 'Not detected');
    set('di-module', map.MODULE||'Unknown');
  }catch(e){ set('di-module','read failed'); }
  loadModules();
}
async function loadModules(){
  const box=document.getElementById('di-modules'), cnt=document.getElementById('di-modcount'); if(!box)return;
  const render=(mods)=>{cnt.textContent=mods.length+' total';
    box.innerHTML=mods.map(m=>{const on=m.st==='on';
      return `<div class="mod-item"><span class="mod-dot ${on?'on':'off'}"></span><div class="mod-info"><div class="mod-name">${m.name}</div><div class="mod-ver">${m.ver}</div></div><span class="mod-badge ${on?'on':'off'}">${on?'ON':'OFF'}</span></div>`;}).join('');};
  try{
    const out=await shell('for d in /data/adb/modules/*/; do [ -d "$d" ] || continue; id=$(basename "$d"); nm=$(grep "^name=" "$d/module.prop" 2>/dev/null | cut -d= -f2); vr=$(grep "^version=" "$d/module.prop" 2>/dev/null | cut -d= -f2); [ -z "$nm" ] && nm="$id"; [ -z "$vr" ] && vr="-"; if [ -f "$d/disable" ]; then s="off"; else s="on"; fi; echo "$s|$nm|$vr"; done');
    if(!out || out.trim()==='DEMO_MODE'){
      render([{st:'on',name:'KABIR X INJECTOR',ver:'v9.2'},{st:'on',name:'TEESimulator-RS',ver:'v6.0.1'},{st:'on',name:'ZygiskNext',ver:'v1.2.4'},{st:'on',name:'Shamiko',ver:'v1.2.1'}]);
      return;
    }
    const mods=out.split('\n').filter(l=>l.includes('|')).map(l=>{const[s,nm,vr]=l.split('|');return{st:s,name:nm,ver:vr};});
    if(mods.length) render(mods); else box.innerHTML='<div class="empty-state" style="padding:16px">No modules found</div>';
  }catch(e){ box.innerHTML='<div class="empty-state" style="padding:16px">Read failed</div>'; }
}


