#!/system/bin/sh

MODDIR="/data/adb/modules/kabir-spoof"
FIREBASE_URL="https://chefz-9866d-default-rtdb.firebaseio.com"

check_firebase_auth() {
    REAL_SERIAL="$(cat "$MODDIR/device.id" 2>/dev/null)"
    [ -z "$REAL_SERIAL" ] && return 1
    RESPONSE="$(curl -s --max-time 5 "${FIREBASE_URL}/devices/${REAL_SERIAL}.json" 2>/dev/null)"
    [ -z "$RESPONSE" ] && return 1
    [ "$RESPONSE" = "null" ] && return 1
    STATUS="$(echo "$RESPONSE" | grep -o '"status":"[^"]*"' | cut -d'"' -f4)"
    EXPIRY="$(echo "$RESPONSE" | grep -o '"expiry":"[^"]*"' | cut -d'"' -f4)"
    [ "$STATUS" != "authorized" ] && return 1
    if [ -n "$EXPIRY" ] && [ "$EXPIRY" != "Lifetime" ]; then
        CURRENT_DATE="$(date +%s)"
        EXPIRY_DATE="$(date -d "$EXPIRY" +%s 2>/dev/null)"
        if [ -n "$EXPIRY_DATE" ] && [ "$CURRENT_DATE" -gt "$EXPIRY_DATE" ]; then
            return 1
        fi
    fi
    return 0
}

get_expiry_date() {
    REAL_SERIAL="$(cat "$MODDIR/device.id" 2>/dev/null)"
    RESPONSE="$(curl -s --max-time 5 "${FIREBASE_URL}/devices/${REAL_SERIAL}.json" 2>/dev/null)"
    EXPIRY="$(echo "$RESPONSE" | grep -o '"expiry":"[^"]*"' | cut -d'"' -f4)"
    echo "$EXPIRY"
}

update_module_status() {
    MODULE_PROP="$MODDIR/module.prop"
    REAL_SERIAL="$(cat "$MODDIR/device.id" 2>/dev/null)"
    
    if check_firebase_auth; then
        EXPIRY="$(get_expiry_date)"
        if [ -n "$EXPIRY" ] && [ "$EXPIRY" != "Lifetime" ]; then
            sed -i "s/^description=.*/description=✅ Authorized until: $EXPIRY/g" "$MODULE_PROP" 2>/dev/null
        else
            sed -i "s/^description=.*/description=✅ Authorized (Lifetime)/g" "$MODULE_PROP" 2>/dev/null
        fi
        if [ -f "$MODDIR/action.sh.bak" ]; then
            mv "$MODDIR/action.sh.bak" "$MODDIR/action.sh" 2>/dev/null
            chmod 0755 "$MODDIR/action.sh" 2>/dev/null
        fi
        if [ -d "$MODDIR/webroot.bak" ]; then
            mv "$MODDIR/webroot.bak" "$MODDIR/webroot" 2>/dev/null
        fi
        if ! grep -q "^action=" "$MODULE_PROP" 2>/dev/null; then
            echo "action=action.sh" >> "$MODULE_PROP"
        fi
        if ! grep -q "^webroot=" "$MODULE_PROP" 2>/dev/null; then
            echo "webroot=webroot" >> "$MODULE_PROP"
        fi
        rm -f "$MODDIR/refresh.sh" 2>/dev/null
    else
        sed -i "s/^description=.*/description=❌ Device not authorized: $REAL_SERIAL/g" "$MODULE_PROP" 2>/dev/null
        if [ -f "$MODDIR/action.sh" ]; then
            mv "$MODDIR/action.sh" "$MODDIR/action.sh.bak" 2>/dev/null
        fi
        if [ -d "$MODDIR/webroot" ]; then
            mv "$MODDIR/webroot" "$MODDIR/webroot.bak" 2>/dev/null
        fi
        sed -i '/^action=/d' "$MODULE_PROP" 2>/dev/null
        sed -i '/^webroot=/d' "$MODULE_PROP" 2>/dev/null
        if ! grep -q "^action=" "$MODULE_PROP" 2>/dev/null; then
            echo "action=refresh.sh" >> "$MODULE_PROP"
        fi
        echo '#!/system/bin/sh' > "$MODDIR/refresh.sh"
        echo 'MODDIR="/data/adb/modules/kabir-spoof"' >> "$MODDIR/refresh.sh"
        echo 'REAL_SERIAL="$(cat "$MODDIR/device.id" 2>/dev/null)"' >> "$MODDIR/refresh.sh"
        echo 'WHATSAPP_NUMBER="0545191150"' >> "$MODDIR/refresh.sh"
        echo 'THANK_MESSAGE="Hello, I want access of Kabir-X INJECTION Module%0ADevice ID: $REAL_SERIAL"' >> "$MODDIR/refresh.sh"
        echo 'am start -a android.intent.action.VIEW -d "https://wa.me/$WHATSAPP_NUMBER?text=$THANK_MESSAGE" >/dev/null 2>&1' >> "$MODDIR/refresh.sh"
        echo 'sleep 2' >> "$MODDIR/refresh.sh"
        echo 'sh "$MODDIR/post-fs-data.sh"' >> "$MODDIR/refresh.sh"
        chmod 0755 "$MODDIR/refresh.sh" 2>/dev/null
    fi
}

sleep 10
update_module_status

while true; do
    sleep 3600
    update_module_status
done &